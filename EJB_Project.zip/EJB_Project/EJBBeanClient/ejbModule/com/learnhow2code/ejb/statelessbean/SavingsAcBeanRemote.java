package com.learnhow2code.ejb.statelessbean;

import java.util.List;

import javax.ejb.Remote;

import com.learnhow2code.jpa.entity.SavingsAccount;

@Remote
public interface SavingsAcBeanRemote {
	

	
	//Sample 3.7: Declare the interface method
	//Sample 6.07: Add new Parameters
	public int newAccount(String accountHolderName, int initialBalance, String Street, String City);
	
//	Add Methods for Deposit, Withdraw and Account Closure
	public int depositMoney(int PersonalBankingId, int amount);
	public int withdrawMoney(int PersonalBankingId, int amount);
	public boolean closeSavingsAc(int PersonalBankingId);
	
	//Find Account & return
	public SavingsAccount findById(int pid);
	public void TransferFund(SavingsAccount fromAc, SavingsAccount toAc, int amount);
	
	//Declare method to Search By Id
	public SavingsAccount queryById(int personalBankingId);
	
	//Declare method to search by name
	public SavingsAccount queryByName(String personName);
	
	//Declare method to List All accounts
	public List<SavingsAccount> queryAllAccounts();
	
	//Declare method to query by balance
	public List<SavingsAccount> queryByBal(int balance, int mode);
}
