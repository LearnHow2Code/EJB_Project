package com.learnhow2code.ejb.statelessbean;

import javax.ejb.Remote;

@Remote
public interface HelloBeanRemote {
	public String sayHello();
	
	//Sample 9.01: Declare Method
	public int getFreeShipmentNumber();
	
}
