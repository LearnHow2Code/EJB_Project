package com.learnhow2code.ejb.statelessbean;

import java.util.List;

import javax.ejb.Remote;

import com.learnhow2code.jpa.entity.Employee;
import com.learnhow2code.jpa.entity.Job;

@Remote
public interface EmpJobBeanRemote {
	
	//Bean Method to add Employee
	public Employee addEmployee(String FName, String MName, String LName, int jobLevel, int jobid);
	public List<Job> queryJobs();
		
	//Sample 8.19: Bean Method for Add Job/Modify Flow
	public Job addJob(String jobDesc, int minExp, int maxExp);
	public List<Employee> queryEmployees();
	public List<Employee> queryEmployees(int jobId);
	
	//Sample 8.29: Edit Employee
	public Employee empFindById(String empId);
	public Job jobFindById(int jobId);
	public Employee editEmployee(String empId, String FName, String MName, String LName, int jobLevel, int jobid );	
}
