package com.learnhow2code.ejb.statefulbean;

import java.util.ArrayList;

import javax.ejb.Remote;

@Remote
public interface ShoppingCartRemote {
	//Sample 2.1: Remote Interface Methods
	ArrayList<String> listCartItems();
	void clearCart();
	void removeProduct(String Name);
	void placeProduct(String Name);

}
