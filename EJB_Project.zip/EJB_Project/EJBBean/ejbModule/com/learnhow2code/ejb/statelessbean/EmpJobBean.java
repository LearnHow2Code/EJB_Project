package com.learnhow2code.ejb.statelessbean;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.learnhow2code.jpa.entity.Employee;
import com.learnhow2code.jpa.entity.Job;

/**
 * Session Bean implementation class EmpJobBean
 */
@Stateless(mappedName = "EmpJobBean")
@LocalBean
public class EmpJobBean implements EmpJobBeanRemote {

	// Create Entiry Manager, UnitName is from persistance.xml
	@PersistenceContext(unitName = "JPASavingsAccount")
	EntityManager em;

	public EmpJobBean() {
		// TODO Auto-generated constructor stub
	}

	// Emplement the Add Employee Method
	@Override
	public Employee addEmployee(String FName, String MName, String LName, int jobLevel, int jobid) {
		// Create Employee Instance
		Employee emp = new Employee();
		emp.setFirstName(FName);
		emp.setMidName(MName);
		emp.setLastName(LName);
		emp.setJobLevel(jobLevel);

		// Generate EmpId and Set it
		String id = "PMA42628M";
		Integer num = (int) (Math.random() * 100000);
		id = id.replace("42628", num.toString());
		emp.setId(id);

		// Hook the Job to Employee. EM will take care of the relation
		Job jobToLink = em.find(Job.class, jobid);
		emp.setJob(jobToLink);
		em.persist(emp);
		return emp;
	}

	@Override
	public List<Job> queryJobs() {
		String JpaSql = "Select J from Job J ";
		Query query = em.createQuery(JpaSql);
		List<Job> jobs = (List<Job>) query.getResultList();
		return jobs;
	}

	// Sample 8.21: Add Job to DB [with 1-Many Relation]
	@Override
	public Job addJob(String jobDesc, int minExp, int maxExp) {
		// 8.21.1: Set Fields
		Job job = new Job();
		job.setJobDesc(jobDesc);
		job.setMinExp(minExp);
		job.setMaxExp(maxExp);

		// 8.21.2: 1-Many Link
		// job.setEmployees(null);

		// 8.21.3: Push to DB
		em.persist(job);
		return job;
	}

	// Sample 8.20: Get all Employees
	@Override
	public List<Employee> queryEmployees() {
		String JpaSql = "Select E from Employee E ";
		Query query = em.createQuery(JpaSql);
		List<Employee> employees = (List<Employee>) query.getResultList();
		return employees;
	}

	// Sample 8.22: Find Employee with Specific Job and Return
	@Override
	public List<Employee> queryEmployees(int jobId) {
		// 8.22.1: Find Job First
		Job job = em.find(Job.class, jobId);

		// 8.22.2: Return Employees. [Null should be checked by the caller]
		// Remember! Job is a one to many entriy
		return job.getEmployees();
	}

	// Sample 8.30: Find Employee & Job by Id
	@Override
	public Employee empFindById(String empId) {
		return em.find(Employee.class, empId);
	}

	@Override
	public Job jobFindById(int jobId) {
		return em.find(Job.class, jobId);
	}

	// Sample 8.31: Find Employee, Update, Persist
	public Employee editEmployee(String empId, String firstName, String midName, String lastName, int jobLevel,
			int jobId) {
		// 8.31.1: Find Employee
		Employee emp = empFindById(empId);

		// 8.31.2: Update Fields
		emp.setFirstName(firstName);
		emp.setMidName(midName);
		emp.setLastName(lastName);
		emp.setJobLevel(jobLevel);
		emp.setJob(jobFindById(jobId));

		// 8.31.3: Persisit Information
		em.persist(emp);
		return emp;
	}
}
