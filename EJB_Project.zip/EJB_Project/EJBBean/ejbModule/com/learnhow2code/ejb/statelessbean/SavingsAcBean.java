package com.learnhow2code.ejb.statelessbean;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.learnhow2code.ejb.statelessbean.SavingsAcBeanRemote;
import com.learnhow2code.jpa.entity.Location;
import com.learnhow2code.jpa.entity.SavingsAccount;

/**
 * Session Bean implementation class SavingsAcBean
 */
@Stateless(mappedName = "SavingsAcBean")
@LocalBean
public class SavingsAcBean implements SavingsAcBeanRemote {
	// UnitName is from persistance.xml
	@PersistenceContext(unitName = "JPASavingsAccount")
	EntityManager em;

	public SavingsAcBean() {
	}

	@Override
    //Sample 3.8: Create New Account. [persist API]
    //Sample 6.08: Make the Change to support new parameter
	public int newAccount(String accountHolderName, int initialBalance, String Street, String City) {
		SavingsAccount account = new SavingsAccount();
		account.setBal(initialBalance);
		account.setpName(accountHolderName);
		
		//Sample 6.09: Create Category Type
		Location loc = new Location();
		loc.setCity(City);
		loc.setStreet(Street);
		account.setLoc(loc);
		
		em.persist(account);
		return account.getPid();
	}

	@Override
	// Deposit amount to Bank Account
	public int depositMoney(int PersonalBankingId, int amount) {
		// Find the Account & call deposit on JPA
		SavingsAccount SavingAc = em.find(SavingsAccount.class, PersonalBankingId);
		return SavingAc.deposit(amount);
	}

	@Override
	// Withdraw amount from Savings Account
	public int withdrawMoney(int PersonalBankingId, int amount) {
		// Find the account & Call withdraw on JPA
		SavingsAccount SavingAc = em.find(SavingsAccount.class, PersonalBankingId);
		return SavingAc.withdraw(amount);
	}

	@Override
	// Close the account
	public boolean closeSavingsAc(int PersonalBankingId) {
		// Sample 4.22: Find the account and delete the record. Note=> em.remove
		boolean ret = false;
		SavingsAccount SavingAc = em.find(SavingsAccount.class, PersonalBankingId);
		if (SavingAc != null) {
			em.remove(SavingAc);
			ret = true;
		}
		return ret;
	}

	// Find account by id and return it
	@Override
	public SavingsAccount findById(int pid) {
		SavingsAccount SavingAc = em.find(SavingsAccount.class, pid);
		return SavingAc;
	}

	// Perform Fund Transfer
	@Override
	public void TransferFund(SavingsAccount fromAc, SavingsAccount toAc, int amount) {
		// First Change the From Account
		SavingsAccount ac1 = em.merge(fromAc);
		ac1.withdraw(amount);

		// Now Change the To Account
		SavingsAccount ac2 = em.merge(toAc);
		ac2.deposit(amount);
	}

	// Use Entity manager to filter account by id
	@Override
	public SavingsAccount queryById(int personalBankingId) {
		SavingsAccount SavingAc = em.find(SavingsAccount.class, personalBankingId);
		return SavingAc;
	}

	// Use JPA QL to filter by account name
	@Override
	public SavingsAccount queryByName(String personName) {
		String JpaSql = "Select sac from SavingsAccount sac where sac.pName = :PersonName";
		Query query = em.createQuery(JpaSql);
		query.setParameter("PersonName", personName);
		SavingsAccount sa = (SavingsAccount) query.getSingleResult();
		return sa;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<SavingsAccount> queryAllAccounts() {
		String JpaSql = "Select sac from SavingsAccount sac";
		Query query = em.createQuery(JpaSql);
		List<SavingsAccount> accounts = query.getResultList();
		return accounts;
	}
	//Use JPA QL to fetch by balance
	@Override
	public List<SavingsAccount> queryByBal(int balance, int mode) {
		//Balance equal
		String JpaSql = "Select sac from SavingsAccount sac where sac.bal = :Balance";
		//Balance less than
		if (mode == -1)
			JpaSql = JpaSql.replace('=', '<');
			  
		//Balance greater than
		if (mode == 1)
			JpaSql = JpaSql.replace('=', '>');
	
		//All set! Get result
		Query query = em.createQuery(JpaSql);
		query.setParameter("Balance", balance);	
		List<SavingsAccount> accounts = query.getResultList();
		return accounts;
	}

}
