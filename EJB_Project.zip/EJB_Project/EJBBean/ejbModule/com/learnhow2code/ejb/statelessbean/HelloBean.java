package com.learnhow2code.ejb.statelessbean;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import com.learnhow2code.ejb.statelessbean.HelloBeanRemote;

/**
 * Session Bean implementation class HelloBean
 */
@Stateless(mappedName = "HelloBean")
@LocalBean
public class HelloBean implements HelloBeanRemote {

    /**
     * Default constructor. 
     */
    public HelloBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String sayHello() {
		//Sample 02: Return Greeting Message
				return "EJB Says: Hello Coding-Example Friends!";
	}

	@Override
	public int getFreeShipmentNumber() {
		//Sample 9.02: Let us pretend this as a 
		//Long Running Task as getting free vehicle by querying 
		//from different shipment company
		int ANumber = (int) (Math.random() * 10000);
		try {
			Thread.sleep(16000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return ANumber;
	}
}
