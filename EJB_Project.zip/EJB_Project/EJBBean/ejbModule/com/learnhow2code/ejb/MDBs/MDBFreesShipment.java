package com.learnhow2code.ejb.MDBs;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import com.learnhow2code.ejb.statelessbean.HelloBeanRemote;

/**
 * Message-Driven Bean implementation class for: MDBFreesShipment
 */
@MessageDriven(
		activationConfig = { 
				@ActivationConfigProperty(
					propertyName = "destination", 
					propertyValue = "java:/jms/queue/FreeShipmentReqQ"), 
				
				@ActivationConfigProperty(
					propertyName = "destinationType", 
					propertyValue = "javax.jms.Queue")
		}, 
		mappedName = "java:/jms/queue/FreeShipmentReqQ")
public class MDBFreesShipment implements MessageListener {

    /**
     * Default constructor. 
     */
    public MDBFreesShipment() {
        // TODO Auto-generated constructor stub
    }
	
	/**
     * @see MessageListener#onMessage(Message)
     */
    // Sample 9.04: Add Reference to the Existing Bean
 	@EJB(beanName = "HelloBean")
 	HelloBeanRemote HBean;
 	
    public void onMessage(Message message) {
    	// Sample 9.15: Print Message Taken For Processing
		System.out.println("Message Taken for Processing");
		try {
			// Sample 09.16: Read Message
			TextMessage msg = (TextMessage) message;
			String str = msg.getText();
			System.out.println("Requested By " + str.substring(0, str.indexOf('^')));
			System.out.println("Net Weight to be Shipped " + str.substring(str.indexOf('^') + 1, str.length()));

			// Sample 09.17: Call EJB to Get Shipment No (Log Running Process)
			int SNo = HBean.getFreeShipmentNumber();
			System.out.println("Shipment Id: " + SNo + " For " + str.substring(0, str.indexOf('^')));
		} 
		catch (JMSException e) {
			e.printStackTrace();
		}
    }
}
