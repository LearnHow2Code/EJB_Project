package com.learnhow2code.ejb.statefulbean;

import java.util.ArrayList;

import javax.ejb.LocalBean;
import javax.ejb.Stateful;

import com.learnhow2code.ejb.statefulbean.ShoppingCartRemote;

/**
 * Session Bean implementation class ShoppingCart
 */
@Stateful(mappedName = "ShoppingCart")
@LocalBean
public class ShoppingCart implements ShoppingCartRemote {
	//Sample 2.2: Shopping Cart ArrayList
	ArrayList<String> Cart;

    /**
     * Default constructor. 
     */
    public ShoppingCart() {
    	//Sample 2.3: Initialize shopping cart array list 
        Cart = new ArrayList<String>();
    }
    
  //Sample 2.4: Implement Remote Interface Methods
	@Override
	public ArrayList<String> listCartItems() {
		return Cart;
	}

	@Override
	public void clearCart() {
		Cart.clear();		
	}

	@Override
	public void removeProduct(String Name){
		Cart.remove(Name);
	}

	@Override
	public void placeProduct(String Name){
		Cart.add(Name);
	}

}
