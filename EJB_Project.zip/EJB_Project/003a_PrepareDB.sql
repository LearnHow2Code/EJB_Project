USE [pubs]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SavingsAc](
	[PersonID] [smallint] IDENTITY(1,1) NOT NULL,
	[PersonName] [nvarchar](50) NOT NULL,
	[Balance] [int] NOT NULL
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[SavingsAc] ADD  CONSTRAINT [DF_SavingsAc_Balance]  DEFAULT ((0)) FOR [Balance]
GO