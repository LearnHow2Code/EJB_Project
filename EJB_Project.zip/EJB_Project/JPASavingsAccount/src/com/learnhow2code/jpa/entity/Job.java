package com.learnhow2code.jpa.entity;

import java.io.Serializable;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;
import static javax.persistence.GenerationType.IDENTITY;
import static javax.persistence.CascadeType.ALL;

/**
 * Entity implementation class for Entity: Job
 *
 */
@Entity

@Table(name = "jobs")
public class Job implements Serializable {

	
	@Id
	@Column(name = "job_id")
	@GeneratedValue(strategy = IDENTITY)
	private int JobId;
	
	@Column(name = "job_desc")
	private String JobDesc;
	
	@Column(name = "min_lvl")
	private int minExp;
	
	@Column(name = "max_lvl")
	private int maxExp;
	
	//One Job may Refer Many Employees
	@OneToMany(cascade = ALL, mappedBy = "job")
	List<Employee> employees = new ArrayList<Employee>();
	
	private static final long serialVersionUID = 1L;
	
	public Job() {
		super();
	}   
	public int getJobId() {
		return this.JobId;
	}

	public void setJobId(int JobId) {
		this.JobId = JobId;
	}   
	public String getJobDesc() {
		return this.JobDesc;
	}

	public void setJobDesc(String JobDesc) {
		this.JobDesc = JobDesc;
	}   
	public int getMinExp() {
		return this.minExp;
	}

	public void setMinExp(int minExp) {
		this.minExp = minExp;
	}   
	public int getMaxExp() {
		return this.maxExp;
	}

	public void setMaxExp(int maxExp) {
		this.maxExp = maxExp;
	}
	public List<Employee> getEmployees() {
		return employees;
	}
	
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
   
}
