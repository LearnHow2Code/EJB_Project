package com.learnhow2code.jpa.entity;

import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Employee
 *
 */
@Entity

@Table(name = "Employee")
public class Employee implements Serializable {

	@Id
	@Column(name = "emp_id")
	private String id;
	
	@Column(name = "fName")
	private String firstName;
	
	@Column(name = "minit")
	private String midName;
	
	@Column(name = "lName")
	private String lastName;
	
	@Column(name = "job_lvl")
	private int jobLevel;
	
	//Many Employees may Refer one Job Entity
	@ManyToOne
	@JoinColumn(name = "job_id")
	private Job job;
	
	public int getJobLevel() {
		return jobLevel;
	}
	public void setJobLevel(int jobLevel) {
		this.jobLevel = jobLevel;
	}
	
	public Job getJob() {
		return job;
	}
	public void setJob(Job job) {
		this.job = job;
	}

	private static final long serialVersionUID = 1L;

	public Employee() {
		super();
	}   
	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}   
	public String getMidName() {
		return this.midName;
	}

	public void setMidName(String midName) {
		this.midName = midName;
	}   
	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}   
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	//Override toString Method
	@Override
	public String toString() {
		return firstName + " " + midName + " " + lastName;
	}
   
}
