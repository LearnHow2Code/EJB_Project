package com.learnhow2code.jpa.entity;

import java.io.Serializable;
import javax.persistence.*;
import static javax.persistence.FetchType.EAGER;

/**
 * Entity implementation class for Entity: SavingsAccount
 *
 */
@Entity
// Sample 3.1: Say the Table Name
@Table(name = "SavingsAc")
public class SavingsAccount implements Serializable {

	private static final long serialVersionUID = 1L;
	
	//Define Linking Column
	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "LocId")
	Location loc;

	@Column(name = "Balance")
	int bal;
	
	@Column(name = "PersonName")
	String pName;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PersonID")
	int pid;

	public SavingsAccount() {
		super();
	}

	public int getBal() {
		return bal;
	}

	public void setBal(int bal) {
		this.bal = bal;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	// Add/Remove Money to/from Savings
	public int deposit(int credit) {
		bal = bal + credit;
		return bal;
	}

	public int withdraw(int debit) {
		bal = bal - debit;
		return bal;
	}

	public Location getLoc() {
		return loc;
	}

	public void setLoc(Location loc) {
		this.loc = loc;
	}

	//Overrdie toString Method
	@Override
	public String toString() {
		String ret = "";
		ret = pName + "[" +  pid + "] - " + bal ; 
		return ret;
	}
}
