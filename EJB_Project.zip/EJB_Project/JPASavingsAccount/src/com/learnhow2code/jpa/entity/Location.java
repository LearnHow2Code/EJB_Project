package com.learnhow2code.jpa.entity;

import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;
import static javax.persistence.GenerationType.IDENTITY;

/**
 * Entity implementation class for Entity: Location
 *
 */
//Point to the Location Table
@Entity

@Table(name = "Location")
public class Location implements Serializable {

	
	//Mapping with Location table in database
	@Id
	@Column(name = "Id")
	@GeneratedValue(strategy = IDENTITY)
	private int Id;
	
	@Column(name = "Street")
	private String Street;
	
	@Column(name = "City")
	private String City;
	
	private static final long serialVersionUID = 1L;

	public Location() {
		super();
	}   
	public int getId() {
		return this.Id;
	}

	public void setId(int Id) {
		this.Id = Id;
	}   
	public String getStreet() {
		return this.Street;
	}

	public void setStreet(String Street) {
		this.Street = Street;
	}   
	public String getCity() {
		return this.City;
	}

	public void setCity(String City) {
		this.City = City;
	}
	
//	String Representation of Entity
	@Override
	public String toString() {
		String ret;
		ret = this.Street + ", " + this.City;
		return ret;
	}
   
}
