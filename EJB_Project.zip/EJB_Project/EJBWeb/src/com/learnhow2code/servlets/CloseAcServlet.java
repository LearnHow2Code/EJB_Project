package com.learnhow2code.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learnhow2code.ejb.statelessbean.SavingsAcBeanRemote;

/**
 * Servlet implementation class CloseAcServlet
 */
@WebServlet("/CloseAcServlet")
public class CloseAcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// Sample 4.13: Declare EJB Stateless Session Bean
	@EJB(beanName = "SavingsAcBean")
	SavingsAcBeanRemote SACBean;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CloseAcServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Call EJB to Close the A/c
		boolean ret = false;
		String pid = request.getParameter("pid");
		if (pid != null && pid.trim().length() > 0) {
			int custid = new Integer(pid).intValue();
			ret = SACBean.closeSavingsAc(custid);
		}

		// Set Request Attribute and Delegate processing to JSP
		request.setAttribute("Action", "close");
		request.setAttribute("CloseVal", new Boolean(ret).toString());
		RequestDispatcher respJSP = request.getRequestDispatcher("SavingsAcResponse.jsp");
		respJSP.forward(request, response);
	}

}
