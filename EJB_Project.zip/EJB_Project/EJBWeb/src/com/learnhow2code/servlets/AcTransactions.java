package com.learnhow2code.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learnhow2code.ejb.statelessbean.SavingsAcBeanRemote;

/**
 * Servlet implementation class AcTransactions
 */
@WebServlet("/AcTransactions")
public class AcTransactions extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// Declare EJB Stateless Session Bean
	@EJB(beanName = "SavingsAcBean")
	SavingsAcBeanRemote SACBean;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AcTransactions() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Sample 4.10: Get Form Field Data
		String pid = request.getParameter("pid");
		if (pid != null && pid.trim().length() > 0) {
			int custid = new Integer(pid).intValue();
			String amount = request.getParameter("amount");
			String action = request.getParameter("transaction");

			// Sample 4.11: Call EJB to perform Transaction
			int iamount = new Integer(amount).intValue();
			if (action.compareToIgnoreCase("Deposit") == 0) {
				int newBalance = 0;
				newBalance = SACBean.depositMoney(custid, iamount);
				request.setAttribute("Action", "deposit");
				request.setAttribute("NewBalance", newBalance);
			} else {
				int newBalance = 0;
				newBalance = SACBean.withdrawMoney(custid, iamount);
				request.setAttribute("Action", "withdraw");
				request.setAttribute("NewBalance", newBalance);
			}

			// Sample 4.12: Delegate response to a JSP File
			RequestDispatcher respJSP = request.getRequestDispatcher("SavingsAcResponse.jsp");
			respJSP.forward(request, response);
		}
	}

}
