package com.learnhow2code.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learnhow2code.ejb.statelessbean.EmpJobBeanRemote;
import com.learnhow2code.jpa.entity.Employee;

/**
 * Servlet implementation class CreateEmployeeSlet
 */
@WebServlet("/CreateEmployeeSlet")
public class CreateEmployeeSlet extends HttpServlet {

	// Sample 8.15: Have EJB Reference via Annotation
	@EJB(beanName = "EmpJobBean")
	EmpJobBeanRemote BeanEJ;

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CreateEmployeeSlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//Check Submit in Progress
		String submit = request.getParameter("submit");
		if (submit != null && submit.trim().length() > 0) {
			//Get other request parameters & call Bean
			String firstName = request.getParameter("fname");
			String midName = request.getParameter("mname");
			String lastName = request.getParameter("lname");
			String level = request.getParameter("level");
			Integer iLevel = new Integer(level);
			String strJobId = request.getParameter("Job");
			Integer iJobId = new Integer(strJobId);
			Employee emp = BeanEJ.addEmployee(firstName, midName, lastName, iLevel.intValue(), iJobId.intValue());

			//Send Information to Browser
			String resp = "Employee Added!. Id: " + emp.getId();
			response.getWriter().println(resp);
		}
	}

}
