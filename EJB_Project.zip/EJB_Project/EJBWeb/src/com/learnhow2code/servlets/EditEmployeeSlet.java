package com.learnhow2code.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learnhow2code.ejb.statelessbean.EmpJobBeanRemote;
import com.learnhow2code.jpa.entity.Employee;

/**
 * Servlet implementation class EditEmployeeSlet
 */
@WebServlet("/EditEmployeeSlet")
public class EditEmployeeSlet extends HttpServlet {
	
	//Sample 8.37: Have reference to EJB Bean
	@EJB(beanName="EmpJobBean")
	EmpJobBeanRemote BeanEJ;

	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditEmployeeSlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Sample 8.38: Get all the Form Field Data
		String submit = request.getParameter("submit");
		if (submit != null && submit.trim().length()> 0) {
			String empId = request.getParameter("EmpId");
			String firstName = request.getParameter("fname");
			String midName = request.getParameter("mname");
			String lastName = request.getParameter("lname");
			String level = request.getParameter("level");
			Integer iLevel = new Integer(level);
			String strJobId = request.getParameter("Job");
			Integer iJobId = new Integer(strJobId);	
			Employee edited = BeanEJ.editEmployee(empId, firstName, midName, lastName, iLevel, iJobId);
			  
			//Sample 8.39: Send Information to Browser
			String resp = "Employee Edited!. Id: " + edited.getId();
			response.getWriter().println(resp);	
		}
	}
}