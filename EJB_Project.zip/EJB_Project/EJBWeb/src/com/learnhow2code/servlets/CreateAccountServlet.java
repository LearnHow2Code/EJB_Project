package com.learnhow2code.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learnhow2code.ejb.statelessbean.SavingsAcBeanRemote;

/**
 * Servlet implementation class CreateAccountServlet
 */
@WebServlet("/CreateAccountServlet")
public class CreateAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// Sample 4.05: Declare EJB Stateless Session Bean
	@EJB(beanName = "SavingsAcBean")
	SavingsAcBeanRemote SACBean;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CreateAccountServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		// Get Form Field Data
		String PersonName = request.getParameter("person_name");
		String InitBalance = request.getParameter("balance");
		
		//For Location Entity
		String Street = request.getParameter("Street");
		String City = request.getParameter("City");
				
		if (PersonName != null && PersonName.trim().length() > 0) {
			// Call EJB to request new account creation
			int balance = new Integer(InitBalance).intValue();
//			int id = SACBean.newAccount(PersonName, balance);
			
			//Create new account
			int id = SACBean.newAccount(PersonName, balance, Street, City );

			// Delegate response to a JSP File
			request.setAttribute("Action", "Add");
			request.setAttribute("NewAccountID", id);
			RequestDispatcher respJSP = request.getRequestDispatcher("SavingsAcResponse.jsp");
			respJSP.forward(request, response);
		}
	}

}
