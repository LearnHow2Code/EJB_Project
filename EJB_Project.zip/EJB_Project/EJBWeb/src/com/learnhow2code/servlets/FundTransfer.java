package com.learnhow2code.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learnhow2code.ejb.statelessbean.SavingsAcBeanRemote;
//import com.learnhow2code.jpa.entity.SavingsAccount;
import com.learnhow2code.jpa.entity.SavingsAccount;

/**
 * Servlet implementation class FundTransfer
 */
@WebServlet("/FundTransfer")
public class FundTransfer extends HttpServlet {
	//Sample 5.07: Declare EJB Stateless Session Bean
	@EJB(beanName="SavingsAcBean")
	SavingsAcBeanRemote SACBean;
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FundTransfer() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Get Form Field Data
		String pidFrom = request.getParameter("pidFrom");
		String pidTo = request.getParameter("pidTo");
		if (pidFrom != null && pidFrom.trim().length() > 0 &&
				pidTo != null && pidTo.trim().length() > 0 ) 
		{
			int FromAc = new Integer(pidFrom).intValue();
			int ToAc = new Integer(pidTo).intValue();
			String amount = request.getParameter("amount");
			
			//Perform Fund Transfer
			int iamount = new Integer(amount).intValue();
			SavingsAccount ac1 = SACBean.findById(FromAc);
			SavingsAccount ac2 = SACBean.findById(ToAc);
			SACBean.TransferFund(
					ac1, 
					ac2, 
					iamount);
			request.setAttribute("Action", "FundTransfer");
			
			//Delegate response to a JSP File
			RequestDispatcher respJSP = request.getRequestDispatcher("SavingsAcResponse.jsp");
			respJSP.forward(request, response);
		}
		
	}

}
