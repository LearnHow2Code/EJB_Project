package com.learnhow2code.servlets;

import java.io.IOException;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learnhow2code.ejb.statelessbean.SavingsAcBeanRemote;
import com.learnhow2code.jpa.entity.SavingsAccount;

/**
 * Servlet implementation class QuerySavingAc
 */
@WebServlet("/QuerySavingAc")
public class QuerySavingAc extends HttpServlet {
	// Have EJB Reference via Annotation
	@EJB(beanName = "SavingsAcBean")
	SavingsAcBeanRemote SACBean;

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public QuerySavingAc() {
		super();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Get the request Parameters
		SavingsAccount account = null;
		String pid = request.getParameter("Pid");
		String submit1 = request.getParameter("Submit1");
		String pname = request.getParameter("Pname");
		String submit2 = request.getParameter("Submit2");
		String balance = request.getParameter("Balance");
		String submit3 = request.getParameter("Submit3");
		String BalSearchOption = request.getParameter("BalSearch");
		String submit4 = request.getParameter("Submit4");

		// Sample 6.06: Search By Customer Id
		if ((pid != null && pid.trim().length() > 0) && (submit1 != null && submit1.trim().length() > 0)
				&& (submit1.equalsIgnoreCase("Search") == true)) {
			int personalBankingId = new Integer(pid).intValue();
			account = SACBean.queryById(personalBankingId);

			// Sample 6.07: Delegate Display output to Query Result JSP
			request.setAttribute("Account", account);
			RequestDispatcher respJSP = request.getRequestDispatcher("QueryResultByIdorName.jsp");
			respJSP.forward(request, response);
		}

		// Search by Owner Name
		if ((pname != null && pname.trim().length() > 0) && (submit2 != null && submit2.trim().length() > 0)
				&& (submit2.equalsIgnoreCase("Search") == true)) {
			account = SACBean.queryByName(pname);
			request.setAttribute("Account", account);
			RequestDispatcher respJSP = request.getRequestDispatcher("QueryResultByIdorName.jsp");
			respJSP.forward(request, response);
		}

		// List all accounts
		if ((submit4 != null && submit4.trim().length() > 0) && submit4.equalsIgnoreCase("Get All Accounts") == true) {
			List<SavingsAccount> accounts = SACBean.queryAllAccounts();
			request.setAttribute("Accounts", accounts);
			RequestDispatcher respJSP = request.getRequestDispatcher("QueryResultMultiple.jsp");
			respJSP.forward(request, response);
		}

		// Search By Balance
		if ((balance != null && balance.trim().length() > 0) && (submit3 != null && submit3.trim().length() > 0)
				&& (submit3.equalsIgnoreCase("Search") == true)) {
			int bal = new Integer(balance).intValue();
			int mode = new Integer(BalSearchOption).intValue();
			List<SavingsAccount> accounts = SACBean.queryByBal(bal, mode);
			request.setAttribute("Accounts", accounts);
			RequestDispatcher respJSP = request.getRequestDispatcher("QueryResultMultiple.jsp");
			respJSP.forward(request, response);
		}
	}
}