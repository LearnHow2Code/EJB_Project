package com.learnhow2code.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learnhow2code.ejb.statelessbean.EmpJobBeanRemote;
import com.learnhow2code.jpa.entity.Job;

/**
 * Servlet implementation class CreateJobSlet
 */
@WebServlet("/CreateJobSlet")
public class CreateJobSlet extends HttpServlet {
	// Sample 8.25: Have EJB Reference via Annotation
	@EJB(beanName = "EmpJobBean")
	EmpJobBeanRemote BeanEJ;

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CreateJobSlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Sample 8.26: Check Submit in Progress
		  String submit = request.getParameter("submit");
		  if (submit != null && submit.trim().length()> 0){
			  
		   //8.27: Get form fields related to Job & add
		   String desc = request.getParameter("JobDesc");
		   int min = new Integer(request.getParameter("min")).intValue();
		   int max = new Integer(request.getParameter("max")).intValue();
		   Job NewJob = BeanEJ.addJob(desc, min, max);
		   
		    //Sample 8.28: Send Information to Browser
		    String resp = "Job Added!. Id: " + NewJob.getJobId();
		    response.getWriter().println(resp);
		  }		
	}
}
